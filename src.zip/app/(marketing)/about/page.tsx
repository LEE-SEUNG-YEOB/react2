export default function About() {
    return (
        <div>
            <h1 className="text-2xl font-bold">About Page</h1>
            <p>Learn more about us here.</p>
        </div>
    )
}
