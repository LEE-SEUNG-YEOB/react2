export default function Shop() {
    return (
        <div>
            <h1 className="text-2xl font-bold">Account Page</h1>
            <p>Manage your account details here.</p>
        </div>
    )
}